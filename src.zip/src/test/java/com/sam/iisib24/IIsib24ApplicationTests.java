package com.sam.iisib24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IIsib24ApplicationTests {

    @Test
    void contextLoads() {
    }

}
